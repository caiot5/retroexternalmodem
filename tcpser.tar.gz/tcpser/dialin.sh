#!/bin/bash

# Configuration
DIAL_NUMBER="8013614839"   # Must match tcpser's -n argument
CLIENT_IP="192.168.5.2"    # Client IP (from pap-secrets)
SERVER_IP="192.168.5.1"    # Server IP
BAUD_RATE="38400"          # Match tcpser's baud rate
SERIAL_PORT="/dev/ttyUSB0" # Serial port for tcpser

# Start tcpser to listen for dial-ups and forward to localhost:1234
./tcpser -d $SERIAL_PORT -s $BAUD_RATE -S $BAUD_RATE -n$DIAL_NUMBER=localhost:1234 &
TCPSER_PID=$!

# Use socat to bridge the TCP socket (localhost:1234) to a pseudo-tty
socat TCP-LISTEN:1234,reuseaddr,fork PTY,link=/tmp/ppp,rawer,wait-slave &
SOCAT_PID=$!

# Wait for pseudo-tty to initialize
sleep 1

# Start pppd on the pseudo-tty with authentication
pppd /dev/ttyUSB0 $BAUD_RATE \
  $SERVER_IP:$CLIENT_IP \
  noauth \
  local \
  lock \
  nodetach \
  debug \
  persist \
  require-pap \
  login &
PPPD_PID=$!

# Cleanup on exit
cleanup() {
  kill $TCPSER_PID $SOCAT_PID $PPPD_PID 2>/dev/null
  rm -f /tmp/ppp
  exit 0
}
trap cleanup SIGINT SIGTERM

# Keep the script running
wait
