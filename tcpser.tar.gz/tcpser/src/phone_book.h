int pb_init(void);
int pb_add(char *from, char *to);
char *pb_search(char *number);
