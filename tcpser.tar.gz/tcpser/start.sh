#!/bin/bash

echo "→ Starting TCPSER (Modem Emulator)..."
./tcpser -d /dev/ttyAMA0 -s 38400 -S 28800 -n2242525=localhost:5432 -n3372234=micronet.ddns.net:2323 &

echo "→ Loading iptables rules..."
iptables -t nat -A POSTROUTING -s 172.16.0.0/24 -j MASQUERADE

echo "→ Starting PPPD wrapper..."
python3 /WiFi2DialUp/pppd-wrapper.py &
